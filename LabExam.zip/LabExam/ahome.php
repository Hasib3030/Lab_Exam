
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Admin's Home Page</title>
</head>
<body>
    <center>
        <form action="#" method="POST">
		    <fieldset>
		      <legend>Admin's Home Page</legend> 
			    <h1 >Welcome BOB !</h1><br>
				<a href='profile.php'>Profile</a><br>
				<a href='login.php'>Change Password</a><br>
				<a href='user.php'>User View</a><br>
				<a href='login.php'>Logout</a><br>
				
               
			</fieldset> 
        </form>
    </center>
</body>
</html>