<!DOCTYPE html>
<html lang="en">
<head>
   
    <title>Profile</title>
</head>
<body>
    <form method="POST" action="">
	  <fieldset>
	  <legend>Profile</legend> 
        <center>
            <table  border="1" width="20%">
                <tr>
                    <td>
                        <h1>Profile</h1>
                    </td>
                </tr>
				<tr>
				
                    <td>
                       <a>id</a>
                    </td>
					<td>
                       <a>17-34349-1</a>
                    </td>
				
				</tr>
				
				<tr>
				
				<td>
                       <a>Name</a>
                    </td>
					<td>
                       <a>BOB</a>
                    </td>
				</tr>
				
				<tr>
				
				<td>
                       <a>User Type</a>
                    </td>
					<td>
                       <a>Admin</a>
                    </td>
				</tr>
				
				<tr>
				    <td width="95%">
				         <a href='ahome.php'>Go Home</a>
				    </td>
				</tr>
	    
            </table>
        
        </center>
	    </fieldset>
    </form>
    
</body>
</html>