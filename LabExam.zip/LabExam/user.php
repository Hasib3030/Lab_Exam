<!DOCTYPE html>
<html lang="en">
<head>
   
    <title>User</title>
</head>
<body>
    <form method="POST" action="#">
	  <fieldset>
	  <legend>User</legend> 
        <center>
            <table  border="1" width="30%">
                <tr>
                    <td colspan='1'>
                        <h1>User</h1>
                    </td>
                </tr>
				<tr>
				     <td>
					  <a>ID</a>
					 </td>
					 
					   <td>
					  <a>Name</a>
					 </td>
					 
					   <td>
					  <a>User Type</a>
					 </td>
				
				</tr>
				
				<tr>
				     <td>
					  <a>17-356545-1</a>
					 </td>
					 
					 <td>
					  <a>Bob</a>
					 </td>
					 
					 <td>
					  <a>Admin</a>
					 </td>
					 
				</tr>
				
				<tr>
				     <td>
					  <a>17-56454-1</a>
					 </td>
					 
					 <td>
					  <a>Anne</a>
					 </td>
					 
					 <td>
					  <a>User</a>
					 </td>
					 
				</tr>
				
				<tr>
				     <td>
					  <a>17-45464-1</a>
					 </td>
					 
					 <td>
					  <a>Kent</a>
					 </td>
					 
					 <td>
					  <a>User</a>
					 </td>
					 
				</tr>
				
				<tr>
				     <td>
					  <a>17-54515-1</a>
					 </td>
					 
					 <td>
					  <a>James</a>
					 </td>
					 
					 <td>
					  <a>Admin</a>
					 </td>
					 
				</tr>
				<tr>
				    <td width="95%">
				         <a href='ahome.php'>Go Home</a>
				    </td>
				</tr>
	
            </table>
        
        </center>
	    </fieldset>
    </form>
    
</body>
</html>