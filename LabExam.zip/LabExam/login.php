
<!DOCTYPE html>
<html lang="en">
<head>
    <title>login</title>
</head>
<body>
    <center>
        <form action="#" method="POST">
		    <fieldset>
		      <legend>Login</legend> 
                <input type="text" name="uname" placeholder="Enter UserName"><br><br>
                <input type="password" name="pass" placeholder="Enter passowrd"><br><br>
                <input type="submit" name="submit" value="LOGIN"><br><br>
			</fieldset> 
        </form>
    </center>
</body>
</html>