
<!DOCTYPE html>
<html lang="en">
<head>
    <title>User Home Page</title>
</head>
<body>
    <center>
        <form action="#" method="POST">
		    <fieldset>
		      <legend>User Home Page</legend> 
			    <h1 >Welcome Anne !</h1><br>
				<a  href='profile.php'>>Profile</a><br>
				<a href='login.php'>>Change Password</a><br>
				<a href='login.php'>Logout</a><br>
				
               
			</fieldset> 
        </form>
    </center>
</body>
</html>